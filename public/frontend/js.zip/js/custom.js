var coordinates2=[ 5,5, 100,50, 50,100, 10,90 ];
drawPolygone('canvas','#f00',coordinates2);

var coordinates=[ 14,84, 105,84, 106,165, 19,164 ];
drawPolygone('canvas','#000',coordinates);

var coordinates3 = [232,61,194,96,169,140,148,190,141,208,137,238,151,265,180,298,218,332,251,343,287,373,333,381,372,388,411,379,450,361,487,330,522,242,541,194,534,154,523,126,487,76,469,55,387,55,332,40,309,38,293,43,268,47,48,30];
drawPolygone('canvas','#000',coordinates3);
      
function drawPolygone(id,color,coordinates){
  var canvas=document.getElementById(id);
  var ctx = canvas.getContext('2d');
  ctx.fillStyle = color;

  ctx.beginPath();
  ctx.moveTo(coordinates[0], coordinates[1]);
  for( item=2 ; item < coordinates.length-1 ; item+=2 ){ctx.lineTo( coordinates[item] , coordinates[item+1] )}

  ctx.closePath();
  ctx.fill();
}